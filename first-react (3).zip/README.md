# What's This
A personal website. Built with using TailwindCSS and ReactJS.

## Usage
To use this source code, simply open the HTML file in a web browser and navigate through the sections using the provided links.

## License
This project is licensed under the [MIT License](LICENSE.md).
---
© 2024 Oguzhan